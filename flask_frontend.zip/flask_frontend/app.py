from flask import Flask, render_template, request, redirect, url_for, session, flash, send_file, send_from_directory
import csv
import os
import numpy as np
import pandas as pd
import joblib
import tensorflow as tf
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras.models import load_model

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# File to store user credentials
CSV_FILE = 'users.csv'
PREDICTION_DIR = 'predictions'
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Define model and scaler paths
MODEL_PATH = 'model/consumption_model.h5'
SCALER_X_PATH = 'model/scaler_X.pkl'
SCALER_Y_PATH = 'model/scaler_y.pkl'

# Ensure directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PREDICTION_DIR, exist_ok=True)

# Load model and scalers
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"Model file not found at {MODEL_PATH}")
if not os.path.exists(SCALER_X_PATH) or not os.path.exists(SCALER_Y_PATH):
    raise FileNotFoundError("Scaler files not found.")

model = load_model(MODEL_PATH)
scaler_X = joblib.load(SCALER_X_PATH)
scaler_y = joblib.load(SCALER_Y_PATH)
print("Model and scalers loaded successfully!")

# Ensure CSV file exists
if not os.path.exists(CSV_FILE):
    with open(CSV_FILE, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['username', 'password'])

@app.route('/')
def home():
    return render_template('welcome.html')

# Required features
REQUIRED_FEATURES = ["Global Reactive Power (kW)", "Voltage (V)", "Global Intensity (A)", 
                     "Sub Metering 1", "Sub Metering 2", "Sub Metering 3"]

# Route to serve graph images
@app.route('/graphs/<filename>')
def serve_graph(filename):
    return send_from_directory(os.path.join(PREDICTION_DIR, 'graphs'), filename)

# Function to generate graphs from predictions
def generate_graphs(predictions_df, username):
    # Set Seaborn style
    sns.set_style("whitegrid")

    # Create a directory for graphs if it doesn't exist
    graph_dir = os.path.join(PREDICTION_DIR, 'graphs')
    os.makedirs(graph_dir, exist_ok=True)

    # Plot each feature
    plt.figure(figsize=(12, 8))

    for i, column in enumerate(predictions_df.columns, 1):
        plt.subplot(3, 2, i)  # Adjust subplot grid (3 rows, 2 columns)
        sns.lineplot(data=predictions_df[column], marker='o', linestyle='-', color='b')
        plt.title(f"{column} Over Time")
        plt.xlabel("Time Step")
        plt.ylabel(column)

    plt.tight_layout()
    graph_path = os.path.join(graph_dir, f"{username}_predictions_graphs.png")
    plt.savefig(graph_path)
    plt.close()  # Close the figure to free memory

#-------------upload_predict--------------------
@app.route('/upload_predict', methods=['POST'])
def predict_from_uploaded_csv():
    predictions_df = None  # Initialize predictions_df

    if 'csv_file' not in request.files:
        flash("❌ No file uploaded!", "error")
        return redirect(url_for('make_prediction'))

    file = request.files['csv_file']

    if file.filename == '':
        flash("❌ No selected file!", "error")
        return redirect(url_for('make_prediction'))

    try:
        df = pd.read_csv(file)
        required_features = scaler_X.feature_names_in_ if hasattr(scaler_X, 'feature_names_in_') else REQUIRED_FEATURES
        missing_features = [col for col in required_features if col not in df.columns]
        if missing_features:
            flash(f"❌ Missing required features: {missing_features}", "error")
            return redirect(url_for('make_prediction'))

        input_data = df[required_features]
        scaled_data = scaler_X.transform(input_data.to_numpy())
        scaled_data = scaled_data.reshape((scaled_data.shape[0], scaled_data.shape[1], 1))
        predictions_scaled = model.predict(scaled_data)
        predictions = scaler_y.inverse_transform(predictions_scaled)

        labels = ['Total Consumption', 'Sub_metering_1', 'Sub_metering_2', 'Sub_metering_3']
        predictions_df = pd.DataFrame(predictions, columns=labels)
        for col in ['Sub_metering_1', 'Sub_metering_2', 'Sub_metering_3']:
            predictions_df[col] = predictions_df[col].abs()

        predictions_df["Predicted GAP (kW)"] = (
            (predictions_df["Total Consumption"] +
             predictions_df["Sub_metering_1"] +
             predictions_df["Sub_metering_2"] +
             predictions_df["Sub_metering_3"]) * 60 / 1000
        )

        results = predictions_df.to_dict(orient="records")

        # Store in session
        session['results'] = results

        # Save predictions to file per user
        if 'username' in session:
            username = session['username']
            save_path = os.path.join(PREDICTION_DIR, f"{username}_predictions.csv")
            predictions_df.to_csv(save_path, index=False)

            # Generate graphs
            generate_graphs(predictions_df, username)

        flash("✅ Predictions generated successfully!", "success")
        return redirect(url_for('result'))

    except Exception as e:
        flash(f"❌ Error processing file: {e}", "error")
        return redirect(url_for('make_prediction'))

#--------------------result-------------------------
@app.route('/result')
def result():
    if 'results' not in session:
        flash("No predictions found. Please upload a file first.", "error")
        return redirect(url_for('make_prediction'))

    predictions = session.pop('results')
    return render_template('result.html', predictions=predictions)

#----------------------login--------------------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with open(CSV_FILE, mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row['username'] == username and row['password'] == password:
                    session['username'] = username
                    flash("Login successful!", "success")
                    return redirect(url_for('dashboard'))
        flash("Invalid credentials.", "error")
        return redirect(url_for('login'))
    return render_template('login.html')

#------------------dashboard---------------------------
@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        flash("Please login first!", "error")
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'])

#-----------------logout---------------------------------
@app.route('/logout')
def logout():
    session.pop('username', None)
    flash("Logged out successfully!", "success")
    return redirect(url_for('home'))

#----------------register-----------------------------
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords do not match.", "error")
            return redirect(url_for('register'))

        with open(CSV_FILE, mode='r') as file:
            reader = csv.DictReader(file)
            if any(row['username'] == username for row in reader):
                flash("Username already exists.", "error")
                return redirect(url_for('register'))

        with open(CSV_FILE, mode='a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([username, password])

        flash("Registration successful! Please login.", "success")
        return redirect(url_for('login'))
    return render_template('register.html')

# ----------------- Prediction Page -----------------
@app.route('/make_prediction', methods=['GET','POST'])
def make_prediction():
    if request.method == 'POST':
        return predict_from_uploaded_csv()
    if 'username' not in session:
        flash("Please login first!", "error")
        return redirect(url_for('login'))
    return render_template('prediction_form.html')

# ----------------- View Predictions -----------------
@app.route('/view_predictions')
def view_predictions():
    if 'username' not in session:
        flash("Please login first!", "error")
        return redirect(url_for('login'))

    username = session['username']
    filename = os.path.join(PREDICTION_DIR, f"{username}_predictions.csv")

    predictions = []
    labels = []
    data = []

    if os.path.isfile(filename):
        df = pd.read_csv(filename)
        predictions = df.to_dict(orient='records')
        labels = list(range(1, len(predictions) + 1))
        data = df["Predicted GAP (kW)"].tolist()

    return render_template('view_predictions.html', predictions=predictions, labels=labels, data=data)

# ---------------- About Model ----------------
@app.route('/about_model')
def about_model():
    return render_template('about_model.html')

# ---------------- Download Predictions -----------------
@app.route('/download_predictions')
def download_predictions():
    if 'username' not in session:
        flash("Please login first!", "error")
        return redirect(url_for('login'))

    username = session['username']
    filename = os.path.join(PREDICTION_DIR, f"{username}_predictions.csv")

    if os.path.isfile(filename):
        return send_file(filename, as_attachment=True)
    else:
        flash("No predictions file found.", "error")
        return redirect(url_for('dashboard'))

# ---------------- Run the App ----------------
if __name__ == '__main__':
    app.run(debug=True)
