document.addEventListener("DOMContentLoaded", function() {
    var ctx = document.getElementById('predictionChart').getContext('2d');

    var labels = JSON.parse(document.getElementById('chartLabels').textContent);
    var data = JSON.parse(document.getElementById('chartData').textContent);

    var chart = new Chart(ctx, {
        type: 'line', // Change to 'bar' if bar graph is preferred
        data: {
            labels: labels,
            datasets: [{
                label: 'Predicted Power Consumption (kWh)',
                backgroundColor: 'rgba(76, 175, 80, 0.2)',
                borderColor: '#4CAF50',
                data: data,
                fill: true,
                tension: 0.2
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Prediction Number'
                    }
                },
                y: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Predicted Power (kWh)'
                    }
                }
            }
        }
    });
});
